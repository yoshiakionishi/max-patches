Open "ds-sample3.maxpat" (Figure 35.12 of the Farnell textbook)
