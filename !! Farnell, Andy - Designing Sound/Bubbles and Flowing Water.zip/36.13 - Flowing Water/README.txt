Open "running-water-polyphony.maxpat" (Figure 36.6 of the Farnell textbook)
